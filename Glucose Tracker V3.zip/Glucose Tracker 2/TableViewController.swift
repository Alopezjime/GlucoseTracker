//
//  TableViewController.swift
//  Glucose Tracker
//
//  Created by Brianna Steele on 12/3/17.
//  Copyright © 2017 Tim & Aron Final. All rights reserved.
//

import UIKit
/*protocol dataFromTableToGraph{
    func cellFilled(info: Array<String>)
    func cellFilledTime(info: Array<String>)
}
 */
class TableViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, DataFromInputToTable {
    var cellFill = ["180"]
    var cellFillTime = ["December 4 2017 11:30 P.M."]
    //var delegate:dataFromTableToGraph? = nil
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return(cellFill.count)
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCell
        cell.cellDate.text = cellFillTime[indexPath.row]
        cell.cellLevel.text = cellFill[indexPath.row]
        return(cell)
    }
 /*
    func fillCellFill(cellFill: Array<String>) ->Array<String>
    {
        let levelArrayCollected = cellFill
        return levelArrayCollected
    }
    func fillCellFill(cellFillTime: Array<String>) ->Array<String>
    {
        let dateArrayCollected = cellFillTime
        return dateArrayCollected
    }
 */
/*
    @IBAction func showGraph(_ sender: Any) {
        if (delegate != nil){
            let levelArrayCollect:Array = cellFill as Array
            delegate!.cellFilled(info: <#T##Array<String>#>)
            let dateArrayCollected:Array = cellFillTime as Array
            delegate!.cellFilledTime(info: <#T##Array<String>#>)
            self.navigationController?.popViewController(animated: true)
        }
    }
  */
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    func userDidEnterDate(info: String)
    {
        let Date = info
        cellFillTime.insert(Date, at: index(ofAccessibilityElement: 1))
    }
    func userDidEnterLevel(info: NSNumber)
    {
        let number : NSNumber = info
        let numberString : String = number.stringValue
        cellFill.insert(numberString, at: index(ofAccessibilityElement: 1))
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showTableVC"{
            let userInputVC: UserInputViewController = segue.destination as! UserInputViewController
            userInputVC.delegate = self
    }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
