//
//  GraphViewController.swift
//  Glucose Tracker
//
//  Created by Brianna Steele on 12/3/17.
//  Copyright © 2017 Tim & Aron Final. All rights reserved.
//

/*import UIKit

class GraphViewController: UIViewController, dataFromTableToGraph {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func cellFilled(info: Array<String>)
    {
        let level = info
    }
    func cellFilledTime(info: Array<String>)
    {
        let Date = info
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showGraphVC"{
            let tableVC: TableViewController = segue.destination as! TableViewController
            tableVC.delegate = self
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}*/
