//
//  UserInputViewController.swift
//  Glucose Tracker
//
//  Created by Brianna Steele on 12/3/17.
//  Copyright © 2017 Tim & Aron Final. All rights reserved.
//

import UIKit

protocol DataFromInputToTable{
    func userDidEnterDate(info: String)
    func userDidEnterLevel(info: NSNumber)
}

class UserInputViewController: UIViewController, UIPickerViewDelegate{
    

    var pickHundredsPlace = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    var pickTensPlace = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    var pickOnesPlace = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    var pickDecimalPlace = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    var Hundreds = 0
    var Tens = 0
    var Ones = 0
    var Decimal = 0
    var Total = 0
    var Date = ""
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    //Declare Interactions from View
    @IBOutlet weak var dateTime: UIDatePicker!
    @IBOutlet weak var levelHundreds: UIPickerView!
    @IBOutlet weak var levelTens: UIPickerView!
    @IBOutlet weak var levelOnes: UIPickerView!
    @IBOutlet weak var levelDecimal: UIPickerView!
    
    //Assign Selected Hundred's Place Value
    func numberOfComponentsHundredsPlace(in levelHundreds: UIPickerView) -> Int
    {
        return 1
    }
    
    func levelHundreds(_ levelHundreds: UIPickerView, titleForRow row: Int, forComponent component: Int) -> Int?
    {
        return pickHundredsPlace[row]
    }
    
    func levelHundreds(_ levelHundreds: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    {
        return pickHundredsPlace.count
    }
    
    func levelHundreds(_ levelHundreds: UIPickerView, didSelectRow row: Int, inComponent component: Int)
    {
        Hundreds = pickHundredsPlace[row]
    }
    
    //Assign Selected Ten's Place Value
    func numberOfComponentsTensPlace(in levelTens: UIPickerView) -> Int
    {
        return 1
    }
    
    func levelTens(_ levelTens: UIPickerView, titleForRow row: Int, forComponent component: Int) -> Int?
    {
        return pickTensPlace[row]
    }
    
    func levelTens(_ levelTens: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    {
        return pickTensPlace.count
    }
    
    func levelTens(_ levelTens: UIPickerView, didSelectRow row: Int, inComponent component: Int)
    {
        Tens = pickTensPlace[row]
    }
    
    //Assign Selected One's Place Value
    func numberOfComponentsOnesPlace(in levelOnes: UIPickerView) -> Int
    {
        return 1
    }
    
    func levelOnes(_ levelOnes: UIPickerView, titleForRow row: Int, forComponent component: Int) -> Int?
    {
        return pickOnesPlace[row]
    }
    
    func levelOnes(_ levelOnes: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    {
        return pickOnesPlace.count
    }
    
    func levelOnes(_ levelOnes: UIPickerView, didSelectRow row: Int, inComponent component: Int)
    {
        Ones = pickOnesPlace[row]
    }
    
    //Assign Selected Decimal Place Value
    func numberOfComponentsDecimal (in levelHundreds: UIPickerView) -> Int
    {
        return 1
    }
    
    func levelDecimal(_ levelDecimal: UIPickerView, titleForRow row: Int, forComponent component: Int) -> Int?
    {
        return pickDecimalPlace[row]
    }
    
    func levelDecimal(_ levelDecimal: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    {
        return pickDecimalPlace.count
    }
    
    func levelDecimal(_ levelDecimal: UIPickerView, didSelectRow row: Int, inComponent component: Int)
    {
        Decimal = pickDecimalPlace[row]
    }
    
    func CreateTotal(Hundreds: Int, Tens: Int, Ones: Int, Decimal: Int) -> Int
    {
        let subTotal = 100 * Hundreds + 10 * Tens + Ones
        Total = subTotal + Int(0.1) * Decimal
        return Total
    }
    func GetTime(_ dateTime: UIDatePicker) -> String
    {
        let Date = DateFormatter.localizedString(from: dateTime.date, dateStyle: .full, timeStyle: .short)
        return Date
    }
 
    var delegate:DataFromInputToTable? = nil
    @IBAction func sendData(_ sender: Any) {
        if (delegate != nil){
            let numCollect:NSValue = Total as NSValue
            delegate!.userDidEnterLevel(info: numCollect as! NSNumber)
            let dateCollect:String = Date as String
            delegate!.userDidEnterDate(info: dateCollect)
            self.navigationController?.popViewController(animated: true)
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
