//
//  TableViewCell.swift
//  Glucose Tracker
//
//  Created by Brianna Steele on 12/4/17.
//  Copyright © 2017 Tim & Aron Final. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var cellLevel: UILabel!
    @IBOutlet weak var cellDate: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
